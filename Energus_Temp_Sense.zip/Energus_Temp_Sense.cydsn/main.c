/*****************************************************************************
* File Name: main.c
*
* Version: 3.0
*
* Description:
*   The main C file for the Temperature measurement with Energus Temp Sensor project. 
* 
* Note:
******************************************************************************
* VTM17
* Neil Moloney
******************************************************************************
* This software is based on software owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*****************************************************************************/
#include <device.h>
#include "measurement.h"
#include <stdio.h>
	
int main(void)
{
	/* Voltages across reference resistor and thermistor*/
	int16 vSense;
	
	/* Temperature value in 100ths of a degree C*/
	int32 iTemp;
    
    /*Decimal Temp*/
    int32 decTemp;
	
	/* Dispaly format string */
	char printBuf[16]={'\0'};

	/*Enable global interrupts*/
	CYGlobalIntEnable; 
	
	/*Start all the hardware components required*/
	ADC_SAR_Seq_1_Start();
    EEPROM_1_Start();
    UART_Start();
    
    int numAdcChannels = 2; // set to 10 for checking the measurement function 
    int i = 0;
    uint16 center = 0x5A; //this will be the address in EEPROM to start searching from ~ around room temp
    int32 vCenter = (EEPROM_1_ReadByte(0x5A) << 8) + EEPROM_1_ReadByte(0x5B);
    int32 vCompare;
    uint adr = 0;
    int vmin = 1450; //centivolts; used for range checking
    int vmax = 2350; //centivolts; used for range checking
	

	for(;;)
    {
    	/* Measure Voltage Across Thermistor*/
        i = 0;      //Reset the channel counter THIS WONT WORK FOR 
        while(i<numAdcChannels){
    	    vSense = MeasureSensorVoltage(i); 
            i++;
            //TODO - if a voltage is measured < 1.51 (60 C), the relay will be flipped - need state machine
        }
        
        /* Use the temperature lookup function call to obtain 
        the temperature corresponding to the resistance measured*/	
        i = 0; 
        adr = 2;
        
        //Ensure that voltage measured is in range
    	while(i<numAdcChannels){
            //TODO - SEARCH FOR first voltage > read in voltage, increment 1 and that is the temp
            // 180 entries in EEPROM, even are voltages, odd are temps
            if (vSense > vCenter){ // check Temps below tCenter
                vCompare = (EEPROM_1_ReadByte(0x5A-adr) << 8) + EEPROM_1_ReadByte(0x5B-adr);
                while (vSense > vCompare){
                    adr=adr+2;
                    vCompare = (EEPROM_1_ReadByte(0x5A-adr) << 8) + EEPROM_1_ReadByte(0x5B-adr);
                }
                iTemp = (EEPROM_1_ReadByte(center-adr+182) << 8) + EEPROM_1_ReadByte(center-adr+183);
            }else if (vSense < vCenter){ // check Temps above tCenter
                vCompare = (EEPROM_1_ReadByte(0x5A+adr) << 8) + EEPROM_1_ReadByte(0x5B+adr);
                while (vSense < vCompare){
                    adr=adr+2;
                    vCompare = (EEPROM_1_ReadByte(0x5A+adr) << 8) + EEPROM_1_ReadByte(0x5B+adr);
                }
                iTemp = (EEPROM_1_ReadByte(center+adr+182) << 8) + EEPROM_1_ReadByte(center+adr+183);
            }else{
                iTemp = (EEPROM_1_ReadByte(0x5A+182) << 8) + EEPROM_1_ReadByte(0x5B+182);
            }
            i++;
        }
        
    	/*Display -- For Debug*/	

    	/*Determine decimal portion of temperature by dividing temperature by 100*/
        decTemp = iTemp;
        
        /*format string to print out over UART*/
        sprintf(printBuf, "Temp=%ld", decTemp); 
		
        /*Print result over UART*/
        UART_PutString(printBuf);
        UART_PutString("\n\r");
        
    }
}

/* [] END OF FILE */
